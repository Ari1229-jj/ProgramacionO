package entidades.cursos;

import entidades.cursos.users.*;
import java.util.*;

public class Curso {
    private String nombre;
    private Instructor instructor;
    private List<Subscriptor> subs;

    public Curso(String nombre, Instructor instructor) {
        this.nombre = nombre;
        this.instructor = instructor;
        this.subs = new ArrayList<>();
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getNombre() {
        return nombre;
    }

    public Instructor getInstructor() {
        return instructor;
    }

    public void setInstructor(Instructor instructor) {
        this.instructor = instructor;
    }

    public void agregarSubscriptor(Subscriptor s) {
        subs.add(s);
    }

    public void eliminarSubscriptor(String nombre) {
        subs.removeIf(s -> s.getNombre().equalsIgnoreCase(nombre));
    }

    public List<Subscriptor> getSubs() {
        return subs;
    }

    @Override
    public String toString() {
        return "Curso: " + nombre + ", Instructor: " + instructor.getNombre() + ", Subscriptores: " + subs.size();
    }
}
