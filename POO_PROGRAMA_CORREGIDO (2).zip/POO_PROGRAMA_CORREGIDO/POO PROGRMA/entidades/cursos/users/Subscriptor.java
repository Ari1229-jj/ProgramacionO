package entidades.cursos.users;

public class Subscriptor extends Usuario {
    private boolean membresiaActiva;

    public Subscriptor(String nombre, int edad, boolean membresiaActiva) {
        super(nombre, edad);
        this.membresiaActiva = membresiaActiva;
    }

    public void setMembresiaActiva(boolean membresiaActiva) {
        this.membresiaActiva = membresiaActiva;
    }

    public boolean isMembresiaActiva() {
        return membresiaActiva;
    }

    @Override
    public String toString() {
        return "Subscriptor: " + nombre + ", Edad: " + edad + ", Membresía activa: " + membresiaActiva;
    }
}
