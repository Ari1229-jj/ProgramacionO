package entidades.cursos.users;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import utils.Conexion;


public class SubscriptorDAO {
    public void guardar(Subscriptor sub) {
        String sql = "INSERT INTO subscriptor (nombre, edad, membresia) VALUES (?, ?, ?)";

        try (Connection conn = Conexion.obtenerConexion();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setString(1, sub.getNombre());
            stmt.setInt(2, sub.getEdad());
            stmt.setBoolean(3, sub.isMembresiaActiva());

            stmt.executeUpdate();
            System.out.println("Subscriptor guardado en la base de datos.");

        } catch (SQLException e) {
            System.out.println("Error al guardar subscriptor: " + e.getMessage());
        }
    }
}