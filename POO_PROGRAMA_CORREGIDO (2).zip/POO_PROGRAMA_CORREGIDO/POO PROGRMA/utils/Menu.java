package utils;

import aplicacion.users.ServicioUsuario;
import entidades.cursos.Curso;
import entidades.cursos.users.Instructor;
import entidades.cursos.users.Subscriptor;
import entidades.cursos.users.SubscriptorDAO;
import java.util.Scanner;



public class Menu {
    private final ServicioUsuario servicio;
    private final Scanner scanner;

    public Menu() {
        servicio = new ServicioUsuario();
        scanner = new Scanner(System.in);
    }

    public void iniciar() {
        int opcion;
        do {
            System.out.println("\n--- MENÚ ---");
            System.out.println("1. Agregar subscriptor");
            System.out.println("2. Listar subscriptores");
            System.out.println("3. Editar subscriptor");
            System.out.println("4. Eliminar subscriptor");
            System.out.println("5. Agregar instructor");
            System.out.println("6. Listar instructores");
            System.out.println("7. Agregar curso");
            System.out.println("8. Listar cursos");
            System.out.println("9. Inscribir subscriptor en curso");
            System.out.println("0. Salir");
            System.out.print("Seleccione una opción: ");
            opcion = scanner.nextInt();
            scanner.nextLine(); // limpiar buffer

            switch (opcion) {
                case 1 -> agregarSubscriptor();
                case 2 -> listarSubscriptores();
                case 3 -> editarSubscriptor();
                case 4 -> eliminarSubscriptor();
                case 5 -> agregarInstructor();
                case 6 -> listarInstructores();
                case 7 -> agregarCurso();
                case 8 -> listarCursos();
                case 9 -> inscribirSubscriptor();
                case 0 -> System.out.println("Saliendo...");
                default -> System.out.println("Opción no válida");
            }
        } while (opcion != 0);
    }

    private void agregarSubscriptor() {
    System.out.print("Nombre: ");
    String nombre = scanner.nextLine();
    System.out.print("Edad: ");
    int edad = scanner.nextInt();
    System.out.print("¿Membresía activa? (true/false): ");
    boolean membresia = scanner.nextBoolean();
    scanner.nextLine();

    Subscriptor subscriptor = new Subscriptor(nombre, edad, membresia);
    servicio.agregarSubscriptor(subscriptor);

    SubscriptorDAO dao = new SubscriptorDAO();
    dao.guardar(subscriptor); 
}


    private void listarSubscriptores() {
        for (Subscriptor s : servicio.listarSubs()) {
            System.out.println(s);
        }
    }

    private void editarSubscriptor() {
        System.out.print("Nombre del subscriptor a editar: ");
        String nombre = scanner.nextLine();
        System.out.print("Nueva edad: ");
        int edad = scanner.nextInt();
        System.out.print("¿Nueva membresía activa? (true/false): ");
        boolean membresia = scanner.nextBoolean();
        scanner.nextLine();
        servicio.editarSubscriptor(nombre, edad, membresia);
    }

    private void eliminarSubscriptor() {
        System.out.print("Nombre del subscriptor a eliminar: ");
        String nombre = scanner.nextLine();
        servicio.eliminarSubscriptor(nombre);
    }

    private void agregarInstructor() {
        System.out.print("Nombre: ");
        String nombre = scanner.nextLine();
        System.out.print("Edad: ");
        int edad = scanner.nextInt();
        scanner.nextLine();
        System.out.print("Especialidad: ");
        String esp = scanner.nextLine();
        servicio.agregarInstructor(new Instructor(nombre, edad, esp));
    }

    private void listarInstructores() {
        for (Instructor i : servicio.listarInstructores()) {
            System.out.println(i);
        }
    }

    private void agregarCurso() {
        System.out.print("Nombre del curso: ");
        String nombreCurso = scanner.nextLine();
        System.out.print("Nombre del instructor: ");
        String nombreInst = scanner.nextLine();

        Instructor encontrado = null;
        for (Instructor i : servicio.listarInstructores()) {
            if (i.getNombre().equalsIgnoreCase(nombreInst)) {
                encontrado = i;
                break;
            }
        }

        if (encontrado != null) {
            servicio.agregarCurso(new Curso(nombreCurso, encontrado));
        } else {
            System.out.println("Instructor no encontrado.");
        }
    }

    private void listarCursos() {
        for (Curso c : servicio.listarCursos()) {
            System.out.println(c);
        }
    }

    private void inscribirSubscriptor() {
        System.out.print("Nombre del curso: ");
        String curso = scanner.nextLine();
        System.out.print("Nombre del subscriptor: ");
        String sub = scanner.nextLine();
        servicio.inscribirSubscriptorACurso(curso, sub);
    }
}
