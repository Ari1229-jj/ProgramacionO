package utils;

import entidades.cursos.users.Instructor;
import entidades.cursos.users.Subscriptor;
import entidades.cursos.users.Usuario;
import java.util.ArrayList;
import java.util.Scanner;

public class UserOperations {

    public static void editarUsuario(Usuario usuario, Scanner scanner) {
        System.out.print("Nuevo nombre: ");
        String nuevoNombre = scanner.nextLine();

        System.out.print("Nueva edad: ");
        int nuevaEdad = scanner.nextInt();
        scanner.nextLine();

        usuario.setNombre(nuevoNombre);
        usuario.setEdad(nuevaEdad);


        if (usuario instanceof Instructor instructor) {
            System.out.print("Nueva especialidad: ");
            String especialidad = scanner.nextLine();
            instructor.setEspecialidad(especialidad);
        }
        if (usuario instanceof Subscriptor subscriptor) {
            System.out.print("Nueva membresía activa (true/false): ");
            boolean membresia = scanner.nextBoolean();
            scanner.nextLine();
            subscriptor.setMembresiaActiva(membresia);
        }

        System.out.println("Usuario editado correctamente.");
    }

    public static void eliminarUsuario(ArrayList<Usuario> usuarios, int index) {
        usuarios.remove(index);
    }
}
