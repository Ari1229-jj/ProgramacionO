package aplicacion.users;

import entidades.cursos.Curso;
import entidades.cursos.users.*;
import java.util.*;

public class ServicioUsuario {
    private List<Subscriptor> subs = new ArrayList<>();
    private List<Instructor> instructores = new ArrayList<>();
    private List<Curso> cursos = new ArrayList<>();

    public void agregarSubscriptor(Subscriptor s) {
        subs.add(s);
    }

    public void eliminarSubscriptor(String nombre) {
        subs.removeIf(s -> s.getNombre().equalsIgnoreCase(nombre));
    }

    public void editarSubscriptor(String nombre, int nuevaEdad, boolean nuevaMembresia) {
        for (Subscriptor s : subs) {
            if (s.getNombre().equalsIgnoreCase(nombre)) {
                s.setEdad(nuevaEdad);
                s.setMembresiaActiva(nuevaMembresia);
            }
        }
    }

    public List<Subscriptor> listarSubs() {
        return subs;
    }
    
    public void agregarInstructor(Instructor i) {
        instructores.add(i);
    }

    public void eliminarInstructor(String nombre) {
        instructores.removeIf(i -> i.getNombre().equalsIgnoreCase(nombre));
    }

    public void editarInstructor(String nombre, int nuevaEdad, String nuevaEsp) {
        for (Instructor i : instructores) {
            if (i.getNombre().equalsIgnoreCase(nombre)) {
                i.setEdad(nuevaEdad);
                i.setEspecialidad(nuevaEsp);
            }
        }
    }

    public List<Instructor> listarInstructores() {
        return instructores;
    }

    public void agregarCurso(Curso c) {
        cursos.add(c);
    }

    public void eliminarCurso(String nombre) {
        cursos.removeIf(c -> c.getNombre().equalsIgnoreCase(nombre));
    }

    public void editarCurso(String nombre, String nuevoNombre, Instructor nuevoInst) {
        for (Curso c : cursos) {
            if (c.getNombre().equalsIgnoreCase(nombre)) {
                c.setNombre(nuevoNombre);
                c.setInstructor(nuevoInst);
            }
        }
    }

    public List<Curso> listarCursos() {
        return cursos;
    }

    public void inscribirSubscriptorACurso(String nombreCurso, String nombreSub) {
        for (Curso c : cursos) {
            if (c.getNombre().equalsIgnoreCase(nombreCurso)) {
                for (Subscriptor s : subs) {
                    if (s.getNombre().equalsIgnoreCase(nombreSub)) {
                        c.agregarSubscriptor(s);
                        break;
                    }
                }
            }
        }
    }
}
