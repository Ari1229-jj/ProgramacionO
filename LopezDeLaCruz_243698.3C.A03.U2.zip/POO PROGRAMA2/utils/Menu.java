package utils;

import java.util.ArrayList;
import java.util.Scanner;
import aplicacion.users.ServicioUsuario;
import aplicacion.cursos.ServicioCurso;
import entidades.users.*;

public class Menu {
    public static void mostrarMenu() {
        Scanner scanner = new Scanner(System.in);
        ServicioUsuario servicioUsuario = new ServicioUsuario();
        ServicioCurso servicioCurso = new ServicioCurso();

        int opcion;
        do {
            System.out.println("\n----- Menú del Gimnasio -----");
            System.out.println("1. Registrar usuario");
            System.out.println("2. Mostrar usuarios");
            System.out.println("3. Editar usuario");
            System.out.println("4. Eliminar usuario");
            System.out.println("5. Registrar curso");
            System.out.println("6. Mostrar cursos");
            System.out.println("7. Eliminar curso");
            System.out.println("8. Asignar subscriptor a curso");
            System.out.println("9. Salir");
            System.out.print("Seleccione una opción: ");
            opcion = scanner.nextInt();
            scanner.nextLine();

            switch (opcion) {
                case 1 -> servicioUsuario.registrarUsuario(scanner);
                case 2 -> servicioUsuario.mostrarUsuarios();
                case 3 -> servicioUsuario.editarUsuario(scanner);
                case 4 -> servicioUsuario.eliminarUsuario(scanner);
                case 5 -> servicioCurso.registrarCurso(scanner);
                case 6 -> servicioCurso.mostrarCursos();
                case 7 -> servicioCurso.eliminarCurso(scanner);
                case 8 -> {
                    ArrayList<Subscriptor> subs = new ArrayList<>();
                    for (Usuario u : servicioUsuario.getUsuarios()) {
                        if (u instanceof Subscriptor s) subs.add(s);
                    }
                    servicioCurso.asignarSubscriptor(scanner, subs);
                }
                case 9 -> System.out.println("Saliendo...");
                default -> System.out.println("Opción inválida. Intente nuevamente.");
            }
        } while (opcion != 9);

        scanner.close();
    }
}
