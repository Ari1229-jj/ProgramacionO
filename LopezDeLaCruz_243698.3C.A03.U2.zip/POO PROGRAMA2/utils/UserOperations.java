package utils;

import java.util.Scanner;
import entidades.users.*;
import entidades.users.Subscriptor;
import entidades.users.Instructor;

public class UserOperations {

    public static void editarUsuario(Usuario usuario, Scanner scanner) {
        System.out.print("Nuevo nombre: ");
        String nuevoNombre = scanner.nextLine();

        System.out.print("Nueva edad: ");
        int nuevaEdad = scanner.nextInt();
        scanner.nextLine();

        usuario.setNombre(nuevoNombre);
        usuario.setEdad(nuevaEdad);

        if (usuario instanceof Instructor instructor) {
            System.out.print("Nueva especialidad: ");
            String especialidad = scanner.nextLine();
            instructor.setEspecialidad(especialidad);
        }

        System.out.println("Usuario editado correctamente.");
    }
}
