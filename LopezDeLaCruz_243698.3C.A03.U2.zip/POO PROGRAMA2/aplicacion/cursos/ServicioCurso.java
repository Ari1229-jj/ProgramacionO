package aplicacion.cursos;

import java.util.ArrayList;
import java.util.Scanner;
import entidades.cursos.Curso;
import entidades.users.Subscriptor;

public class ServicioCurso {
    private ArrayList<Curso> cursos;

    public ServicioCurso() {
        cursos = new ArrayList<>();
    }

    public void registrarCurso(Scanner scanner) {
        System.out.print("Nombre del curso: ");
        String nombre = scanner.nextLine();
        System.out.print("Descripción: ");
        String descripcion = scanner.nextLine();
        System.out.print("Duración (semanas): ");
        int duracion = scanner.nextInt();
        scanner.nextLine();

        Curso curso = new Curso(nombre, descripcion, duracion);
        cursos.add(curso);
        System.out.println("Curso registrado correctamente.");
    }

    public void mostrarCursos() {
        if (cursos.isEmpty()) {
            System.out.println("No hay cursos registrados.");
        } else {
            for (int i = 0; i < cursos.size(); i++) {
                System.out.println((i + 1) + ". " + cursos.get(i));
            }
        }
    }

    public void eliminarCurso(Scanner scanner) {
        mostrarCursos();
        if (cursos.isEmpty()) return;

        System.out.print("Seleccione el número del curso a eliminar: ");
        int index = scanner.nextInt() - 1;
        scanner.nextLine();

        if (index >= 0 && index < cursos.size()) {
            cursos.remove(index);
            System.out.println("Curso eliminado correctamente.");
        } else {
            System.out.println("Índice inválido.");
        }
    }

    public ArrayList<Curso> getCursos() {
        return cursos;
    }

    public void asignarSubscriptor(Scanner scanner, ArrayList<Subscriptor> subs) {
        if (cursos.isEmpty() || subs.isEmpty()) {
            System.out.println("Debe haber al menos un curso y un subscriptor.");
            return;
        }

        System.out.println("Seleccione subscriptor:");
        for (int i = 0; i < subs.size(); i++) {
            System.out.println((i + 1) + ". " + subs.get(i));
        }
        int subIndex = scanner.nextInt() - 1;
        scanner.nextLine();

        System.out.println("Seleccione curso:");
        for (int i = 0; i < cursos.size(); i++) {
            System.out.println((i + 1) + ". " + cursos.get(i));
        }
        int cursoIndex = scanner.nextInt() - 1;
        scanner.nextLine();

        if (subIndex >= 0 && subIndex < subs.size() && cursoIndex >= 0 && cursoIndex < cursos.size()) {
            Subscriptor s = subs.get(subIndex);
            Curso c = cursos.get(cursoIndex);
            s.asignarCurso(c);
            System.out.println("Subscriptor asignado al curso correctamente.");
        } else {
            System.out.println("Índices inválidos.");
        }
    }
}
