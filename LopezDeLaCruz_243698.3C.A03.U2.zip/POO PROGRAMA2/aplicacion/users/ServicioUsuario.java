package aplicacion.users;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;


import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Scanner;
import entidades.users.*;
import utils.UserOperations;

public class ServicioUsuario {
    private ArrayList<Usuario> usuarios = new ArrayList<>();

    public ServicioUsuario() {
        usuarios = new ArrayList<>();
    }

    public void registrarUsuario(Scanner scanner) {
    System.out.println("Seleccione tipo de usuario:");
    System.out.println("1. Instructor");
    System.out.println("2. Subscriptor");
    int tipo = scanner.nextInt();
    scanner.nextLine();

    System.out.print("Nombre: ");
    String nombre = scanner.nextLine();

    System.out.print("Edad: ");
    int edad = scanner.nextInt();
    scanner.nextLine();

    Usuario usuario;
    String tipoUsuario;
    String especialidad = null;

    if (tipo == 1) {
        tipoUsuario = "instructor";
        System.out.print("Especialidad: ");
        especialidad = scanner.nextLine();
        usuario = new Instructor(nombre, edad, especialidad);
    } else {
        tipoUsuario = "subscriptor";
        usuario = new Subscriptor(nombre, edad);
    }

    
    usuarios.add(usuario);
    System.out.println("Usuario registrado en memoria.");


    try (Connection conn = utils.DBConnection.getConnection()) {
        String sql = "INSERT INTO usuarios (nombre, edad, tipo, especialidad) VALUES (?, ?, ?, ?)";
        PreparedStatement stmt = conn.prepareStatement(sql);
        stmt.setString(1, nombre);
        stmt.setInt(2, edad);
        stmt.setString(3, tipoUsuario);
        stmt.setString(4, tipoUsuario.equals("instructor") ? especialidad : null);

        stmt.executeUpdate();
        System.out.println("Usuario guardado en la base de datos.");
    } catch (SQLException e) {
        System.out.println("Error al guardar en la base de datos:");
        e.printStackTrace();
    }
}

    public void mostrarUsuarios() {
        if (usuarios.isEmpty()) {
            System.out.println("No hay usuarios registrados.");
        } else {
            for (int i = 0; i < usuarios.size(); i++) {
                System.out.println((i + 1) + ". " + usuarios.get(i));
            }
        }
    }

    public void editarUsuario(Scanner scanner) {
        mostrarUsuarios();
        if (usuarios.isEmpty()) return;

        System.out.print("Seleccione el número del usuario a editar: ");
        int index = scanner.nextInt() - 1;
        scanner.nextLine();

        if (index >= 0 && index < usuarios.size()) {
            UserOperations.editarUsuario(usuarios.get(index), scanner);
        } else {
            System.out.println("Índice inválido.");
        }
    }

    public void eliminarUsuario(Scanner scanner) {
        mostrarUsuarios();
        if (usuarios.isEmpty()) return;

        System.out.print("Seleccione el número del usuario a eliminar: ");
        int index = scanner.nextInt() - 1;
        scanner.nextLine();

        if (index >= 0 && index < usuarios.size()) {
            usuarios.remove(index);
            System.out.println("Usuario eliminado correctamente.");
        } else {
            System.out.println("Índice inválido.");
        }
    }

    public ArrayList<Usuario> getUsuarios() {
        return usuarios;
    }

    public void mostrarUsuariosDesdeBD() {
    try (Connection conn = utils.DBConnection.getConnection()) {
        String sql = "SELECT * FROM usuarios";
        PreparedStatement stmt = conn.prepareStatement(sql);
        var rs = stmt.executeQuery();

        while (rs.next()) {
            int id = rs.getInt("id");
            String nombre = rs.getString("nombre");
            int edad = rs.getInt("edad");
            String tipo = rs.getString("tipo");
            String especialidad = rs.getString("especialidad");

            if ("instructor".equals(tipo)) {
                System.out.println("ID: " + id + " | Instructor: " + nombre + ", Edad: " + edad + ", Especialidad: " + especialidad);
            } else {
                System.out.println("ID: " + id + " | Subscriptor: " + nombre + ", Edad: " + edad);
            }
        }
    } catch (SQLException e) {
        e.printStackTrace();
    }
}

}
