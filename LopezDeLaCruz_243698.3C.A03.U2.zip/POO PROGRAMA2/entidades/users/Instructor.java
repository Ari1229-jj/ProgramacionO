package entidades.users;

public class Instructor extends Usuario {
    private String especialidad;

    public Instructor(String nombre, int edad, String especialidad) {
        super(nombre, edad);
        this.especialidad = especialidad;
    }

    public void setEspecialidad(String especialidad) {
        this.especialidad = especialidad;
    }

    public String getEspecialidad() {
    return especialidad;
}


    @Override
    public String toString() {
        return "Instructor: " + nombre + ", Edad: " + edad + ", Especialidad: " + especialidad;
    }
}
