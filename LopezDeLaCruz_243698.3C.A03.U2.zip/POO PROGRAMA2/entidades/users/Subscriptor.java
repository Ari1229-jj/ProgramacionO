package entidades.users;

import java.util.ArrayList;
import entidades.cursos.Curso;

public class Subscriptor extends Usuario {
    private ArrayList<Curso> cursos;

    public Subscriptor(String nombre, int edad) {
        super(nombre, edad);
        this.cursos = new ArrayList<>();
    }

    public void asignarCurso(Curso curso) {
        this.cursos.add(curso);
    }

    public void eliminarCurso(Curso curso) {
        this.cursos.remove(curso);
    }

    @Override
    public String toString() {
        return "Subscriptor: " + nombre + ", Edad: " + edad + ", Cursos asignados: " + cursos.size();
    }
}
