package entidades.cursos;

public class Curso {
    private String nombre;
    private String descripcion;
    private int duracion;

    public Curso(String nombre, String descripcion, int duracion) {
        this.nombre = nombre;
        this.descripcion = descripcion;
        this.duracion = duracion;
    }

    @Override
    public String toString() {
        return "Curso: " + nombre + ", " + descripcion + " (" + duracion + " semanas)";
    }
}
